"""
Configuration for Recommendation Agent.

This file reads all required environment variables
from Modal Secrets (or .env during local development).
"""

import os


# ==========================================================
# Qdrant Configuration
# ==========================================================

QDRANT_URL = os.getenv("QDRANT_URL")

QDRANT_API_KEY = os.getenv("QDRANT_API_KEY")

QDRANT_COLLECTION = os.getenv(
    "QDRANT_COLLECTION",
    "manas_knowledge"
)


# ==========================================================
# Embedding Model
# ==========================================================

EMBEDDING_MODEL = os.getenv(
    "EMBEDDING_MODEL",
    "BAAI/bge-base-en-v1.5"
)