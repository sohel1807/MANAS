"""
Qdrant Vector Store

Responsible for:
- Connecting to Qdrant
- Managing collections
- Uploading vectors
- Searching vectors
"""

from qdrant_client import QdrantClient

from recommendation_agent.config import (
    QDRANT_URL,
    QDRANT_API_KEY,
)


class VectorStore:

    def __init__(self):
        """
        Initialize Qdrant client.
        """

        self.client = QdrantClient(
            url=QDRANT_URL,
            api_key=QDRANT_API_KEY
        )